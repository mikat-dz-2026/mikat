import { useEffect, useState } from "react";
import { Card } from "@/components/Shell";
import { getTools, saveTools, exportAll, importAll, fmtTime, type Tools } from "@/lib/store";

const TEMPLATES = [
  { cat: "العبادات", title: "المحافظة على الصلاة", axes: "مكانة الصلاة، أثرها في السلوك، وأسباب المحافظة عليها في وقتها.", refs: "البقرة: 238؛ العنكبوت: 45" },
  { cat: "الأسرة وصلة الرحم", title: "بر الوالدين", axes: "حق الوالدين، لين القول، والإحسان إليهما في حياتهما وبعد وفاتهما.", refs: "الإسراء: 23-24" },
  { cat: "الأخلاق", title: "حفظ اللسان", axes: "اجتناب الغيبة، وزن الكلمة، والكلام الطيب.", refs: "ق: 18؛ الحجرات: 12" },
  { cat: "الأخلاق", title: "الأمانة في حياة المسلم", axes: "الأمانة في العبادة والعمل والمال، وأثرها في الثقة بين الناس.", refs: "الأحزاب: 72؛ النساء: 58" },
  { cat: "الأسرة وصلة الرحم", title: "صلة الرحم", axes: "صور الصلة العملية، وإصلاح القطيعة بحكمة.", refs: "محمد: 22؛ النساء: 1" },
  { cat: "المواسم والمناسبات", title: "الاستعداد لرمضان", axes: "التوبة، تنظيم الوقت، والتهيؤ للعبادة.", refs: "البقرة: 183-185" },
];
const EID = [
  { title: "خطبة عيد الفطر", axes: "شكر الله على إتمام الصيام، زكاة الفطر، صلة الأرحام والتسامح، الثبات على الطاعة بعد رمضان." },
  { title: "خطبة عيد الأضحى", axes: "قصة إبراهيم عليه السلام والتضحية، أحكام الأضحية، التكافل مع الفقراء، أيام التشريق." },
];
const STEPS = [
  "اكتب خطبتك أو الصقها في المحرر، أو اختر نموذجًا من «المكتبة»، وحدّد المدة بالدقائق.",
  "أضف بأزرار «وقفة» و«دعاء» و«آية» علامات في مواضعها، ولوّن الكلمات بالنبرة القوية أو العاطفية.",
  "في «نقاط المديرية» اكتب النقاط المطلوبة، وضع علامة عند كل نقطة غطيتها.",
  "اضغط «تشغيل الملقّن»، ثم «اضبط السرعة على الوقت»، ثم «تشغيل».",
  "راقب «متقدم» أو «متأخر» في الأعلى، ويحمرّ المؤقت في آخر دقيقتين، ولمس النص يوقف التمرير.",
  "احفظ الخطبة في «ميقاتي» بعنوانها، وخذ نسخة احتياطية من حين لآخر.",
];

const TABS = ["📚 المكتبة", "📋 نقاط المديرية", "🤲 الأدعية", "🗓️ ملاحظات", "🌙 الأعياد", "📖 المراجع", "💾 نسخة احتياطية", "❓ الاستعمال"] as const;

export function ImamTools({ onUse, onSaveCurrent }: { onUse: (title: string, body: string) => void; onSaveCurrent: () => { title: string; html: string; minutes: number } }) {
  const [tab, setTab] = useState<(typeof TABS)[number]>(TABS[0]);
  const [t, setT] = useState<Tools>(getTools());
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("كل الموضوعات");
  const [dua, setDua] = useState("");
  const [msg, setMsg] = useState("");
  useEffect(() => setT(getTools()), []);
  const up = (p: Partial<Tools>) => { saveTools(p); setT({ ...t, ...p }); };
  const tpl = TEMPLATES.filter((x) => (cat === "كل الموضوعات" || x.cat === cat) && (x.title + x.axes).includes(q));
  const mine = t.library.filter((x) => x.title.includes(q) || x.html.includes(q));
  const points = t.points.split("\n").filter((l) => l.trim());
  const btn = "rounded-xl bg-primary px-3 py-2 text-sm font-bold text-primary-foreground";
  const field = "w-full rounded-xl border bg-background p-3";

  const shareApp = async () => {
    const url = window.location.origin;
    if (navigator.share) await navigator.share({ title: "منصة ميقات الخطيب", url }).catch(() => {});
    else { await navigator.clipboard.writeText(url); setMsg("✅ نُسخ الرابط"); }
  };

  return (
    <Card title="🧰 أدوات الخطيب">
      <div className="-mx-1 mb-3 flex gap-2 overflow-x-auto pb-1">
        {TABS.map((x) => (
          <button key={x} onClick={() => { setTab(x); setMsg(""); }} className={`shrink-0 rounded-full px-3 py-1.5 text-sm ${tab === x ? "bg-primary text-primary-foreground" : "bg-muted"}`}>{x}</button>
        ))}
      </div>

      {tab === "📚 المكتبة" && (
        <div className="space-y-3">
          <button className={`${btn} w-full`} onClick={() => { const c = onSaveCurrent(); up({ library: [{ id: Date.now().toString(), ...c, date: new Date().toISOString() }, ...t.library] }); setMsg("✅ حُفظت الخطبة في ميقاتي"); }}>💾 حفظ الخطبة الحالية في المكتبة</button>
          {msg && <p className="text-center text-sm font-bold text-primary">{msg}</p>}
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="🔍 ابحث في النماذج والخطب المحفوظة" className={field} />
          <h3 className="text-sm text-primary">ميقاتي: خطبي المحفوظة ({t.library.length})</h3>
          {mine.length === 0 && <p className="text-sm text-muted-foreground">لا توجد خطب محفوظة بعد.</p>}
          {mine.map((s) => (
            <div key={s.id} className="flex items-center gap-2 rounded-xl border p-3">
              <div className="flex-1"><b className="text-sm">{s.title}</b><div className="text-xs text-muted-foreground">{s.minutes} د · {fmtTime(s.date)}</div></div>
              <button className="text-sm font-bold text-primary" onClick={() => onUse(s.title, s.html)}>فتح</button>
              <button className="text-sm text-destructive" onClick={() => up({ library: t.library.filter((x) => x.id !== s.id) })}>حذف</button>
            </div>
          ))}
          <h3 className="pt-2 text-sm text-primary">نماذج خطب جاهزة للتطوير</h3>
          <select value={cat} onChange={(e) => setCat(e.target.value)} className={field}>
            {["كل الموضوعات", "العبادات", "الأخلاق", "الأسرة وصلة الرحم", "المواسم والمناسبات"].map((c) => <option key={c}>{c}</option>)}
          </select>
          {tpl.map((x) => (
            <div key={x.title} className="rounded-xl border p-3 text-sm">
              <b>{x.title}</b><p className="text-muted-foreground">محاور: {x.axes}</p>
              <p className="text-xs">مراجع للاستدلال: {x.refs}</p>
              <button className="mt-1 font-bold text-primary" onClick={() => onUse(x.title, `<b>${x.title}</b><br>محاور الخطبة: ${x.axes}<br>المراجع: ${x.refs}<br><br>`)}>استخدام النموذج في المحرر ←</button>
            </div>
          ))}
        </div>
      )}

      {tab === "📋 نقاط المديرية" && (
        <div className="space-y-2">
          <textarea value={t.points} onChange={(e) => up({ points: e.target.value, checked: [] })} rows={4} placeholder="اكتب كل نقطة في سطر" className={field} />
          {points.map((p, i) => (
            <label key={i} className="flex items-center gap-2 rounded-xl border p-2 text-sm">
              <input type="checkbox" className="size-5 accent-current text-primary" checked={t.checked.includes(i)} onChange={() => up({ checked: t.checked.includes(i) ? t.checked.filter((x) => x !== i) : [...t.checked, i] })} />
              <span className={t.checked.includes(i) ? "line-through opacity-60" : ""}>{p}</span>
            </label>
          ))}
          {points.length > 0 && <p className="text-xs text-muted-foreground">غطيت {t.checked.length} من {points.length}</p>}
        </div>
      )}

      {tab === "🤲 الأدعية" && (
        <div className="space-y-2">
          <p className="text-xs text-muted-foreground">مساحة شخصية لأدعيتك، أضف المرجع إن وجد.</p>
          <textarea value={dua} onChange={(e) => setDua(e.target.value)} rows={3} placeholder="دعاء أو ذكر مع مرجعه" className={field} />
          <button className={`${btn} w-full`} onClick={() => { if (dua.trim()) { up({ duas: [{ id: Date.now().toString(), text: dua.trim() }, ...t.duas] }); setDua(""); } }}>حفظ في قائمتي</button>
          {t.duas.map((d) => (
            <div key={d.id} className="flex gap-2 rounded-xl border p-3 text-sm">
              <p className="flex-1">{d.text}</p>
              <button className="text-primary" onClick={() => onUse("", `<br><span class="tone-soft">${d.text}</span>`)}>＋ للخطبة</button>
              <button className="text-destructive" onClick={() => up({ duas: t.duas.filter((x) => x.id !== d.id) })}>✕</button>
            </div>
          ))}
        </div>
      )}

      {tab === "🗓️ ملاحظات" && (
        <textarea value={t.notes} onChange={(e) => up({ notes: e.target.value })} rows={8} placeholder="أفكار وموضوعات قادمة… تحفظ تلقائيًا" className={field} />
      )}

      {tab === "🌙 الأعياد" && (
        <div className="space-y-2">
          <p className="text-xs text-muted-foreground">محاور مقترحة للتطوير، وليست نصوصًا جاهزة. راجع الآيات والأحاديث من مصادرها.</p>
          {EID.map((x) => (
            <div key={x.title} className="rounded-xl border p-3 text-sm">
              <b>{x.title}</b><p className="text-muted-foreground">{x.axes}</p>
              <button className="mt-1 font-bold text-primary" onClick={() => onUse(x.title, `<b>${x.title}</b><br>المحاور: ${x.axes}<br><br>`)}>استخدام في المحرر ←</button>
            </div>
          ))}
        </div>
      )}

      {tab === "📖 المراجع" && (
        <div className="space-y-2 text-sm">
          <p>المكتبة الشاملة: مكتبة رقمية عربية للتحقق من نص أو نسبة قول إلى كتابه قبل ذكره على المنبر.</p>
          <a href="https://shamela.ws" target="_blank" rel="noreferrer" className={`${btn} block text-center`}>فتح المكتبة الشاملة ↗</a>
          <p className="text-xs text-muted-foreground">تحقق من درجة الحديث من أهل العلم، وراجع طالب علم عند أي شك.</p>
          <button onClick={shareApp} className="w-full rounded-xl border-2 border-primary py-2 font-bold text-primary">📤 شارك التطبيق مع إمام</button>
          {msg && <p className="text-center font-bold text-primary">{msg}</p>}
        </div>
      )}

      {tab === "💾 نسخة احتياطية" && (
        <div className="space-y-2 text-sm">
          <p className="text-muted-foreground">تحفظ خطبك وملاحظاتك وأدعيتك ونقاطك والأسئلة والتعليمات. احتفظ بها في مكان آمن ولا ترسلها لأحد.</p>
          <button className={`${btn} w-full`} onClick={() => {
            const a = document.createElement("a");
            a.href = URL.createObjectURL(new Blob([exportAll()], { type: "application/json" }));
            a.download = `miqat-backup-${new Date().toISOString().slice(0, 10)}.json`; a.click();
          }}>💾 تنزيل نسخة احتياطية شاملة</button>
          <label className="block w-full cursor-pointer rounded-xl border-2 border-primary py-2 text-center font-bold text-primary">♻️ استرجاع نسخة
            <input type="file" accept="application/json" className="hidden" onChange={async (e) => {
              const f = e.target.files?.[0]; if (!f) return;
              try { importAll(await f.text()); setT(getTools()); setMsg("✅ تم الاسترجاع"); } catch { setMsg("❌ الملف غير صالح"); }
            }} />
          </label>
          {msg && <p className="text-center font-bold text-primary">{msg}</p>}
        </div>
      )}

      {tab === "❓ الاستعمال" && (
        <ol className="list-decimal space-y-2 pr-5 text-sm">{STEPS.map((s) => <li key={s}>{s}</li>)}</ol>
      )}
    </Card>
  );
}
