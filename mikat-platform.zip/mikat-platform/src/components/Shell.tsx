import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";

export function Shell({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="mx-auto min-h-screen max-w-xl pb-16">
      <header className="bg-hero sticky top-0 z-10 flex items-center justify-between px-4 py-3 text-primary-foreground shadow-lg">
        <h1 className="text-lg">{title}</h1>
        <Link to="/" className="rounded-full bg-primary-foreground/15 px-3 py-1 text-sm">الرئيسية ←</Link>
      </header>
      <main className="space-y-4 p-4">{children}</main>
    </div>
  );
}

export function Card({ title, children }: { title?: string; children: ReactNode }) {
  return (
    <section className="rounded-2xl border bg-card p-4 shadow-sm">
      {title && <h2 className="mb-3 text-base text-primary">{title}</h2>}
      {children}
    </section>
  );
}
