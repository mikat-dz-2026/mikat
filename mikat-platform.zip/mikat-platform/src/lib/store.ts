// Local closed "central hub": all portals share one encoded store in this browser.
export type Question = { id: string; text: string; topic: string; date: string; answered: boolean };
export type Directive = { id: string; title: string; body: string; date: string };

const HUB = "miqat_hub_v1";
const EVT = "miqat-hub-change";
type Hub = { questions: Question[]; directives: Directive[]; speech: string | null };

const enc = (o: unknown) => btoa(unescape(encodeURIComponent(JSON.stringify(o))));
const dec = (s: string) => JSON.parse(decodeURIComponent(escape(atob(s))));

function seed(): Hub {
  const now = new Date().toISOString();
  return {
    questions: [
      { id: "s1", text: "هل تجوز صلاة تحية المسجد أثناء الخطبة؟", topic: "أحكام الصلاة", date: now, answered: false },
    ],
    directives: [
      { id: "s1", title: "خطبة موحدة: فضل صلة الرحم", body: "يرجى من السادة الأئمة تخصيص خطبة هذه الجمعة لموضوع صلة الرحم مع عدم تجاوز 20 دقيقة.", date: now },
    ],
    speech: null,
  };
}

function load(): Hub {
  if (typeof window === "undefined") return seed();
  try {
    const raw = localStorage.getItem(HUB);
    if (raw) return dec(raw) as Hub;
  } catch { /* ignore */ }
  const h = seed();
  localStorage.setItem(HUB, enc(h));
  return h;
}

function write(patch: Partial<Hub>) {
  const h = { ...load(), ...patch };
  localStorage.setItem(HUB, enc(h));
  window.dispatchEvent(new Event(EVT));
}

export const getQuestions = () => load().questions;
export const saveQuestions = (questions: Question[]) => write({ questions });
export const addQuestion = (text: string, topic: string) =>
  write({ questions: [...load().questions, { id: Date.now().toString(), text, topic, date: new Date().toISOString(), answered: false }] });
export const getDirectives = () => load().directives;
export const addDirective = (title: string, body: string) =>
  write({ directives: [{ id: Date.now().toString(), title, body, date: new Date().toISOString() }, ...load().directives] });
export const getSpeech = () => load().speech;
export const saveSpeech = (speech: string) => write({ speech });

/** Calls cb whenever the hub changes (same tab or other tabs). */
export function subscribe(cb: () => void) {
  const onStorage = (e: StorageEvent) => { if (e.key === HUB) cb(); };
  window.addEventListener(EVT, cb);
  window.addEventListener("storage", onStorage);
  return () => { window.removeEventListener(EVT, cb); window.removeEventListener("storage", onStorage); };
}

export const fmtTime = (iso: string) =>
  new Date(iso).toLocaleString("ar-DZ", { weekday: "long", hour: "2-digit", minute: "2-digit", day: "numeric", month: "short" });

export function summarize(text: string): string {
  const sentences = text.replace(/\s+/g, " ").split(/(?<=[.!؟?،:])\s+/).map((s) => s.trim()).filter((s) => s.length > 15);
  const picked = sentences.slice(0, 3).join(" ");
  return `🕌 ملخص خطبة الجمعة\n\n${picked || text.slice(0, 280)}\n\n📿 نسأل الله أن ينفعنا بما سمعنا.\n#خطبة_الجمعة #المسجد #الجزائر`;
}

// ---- Imam personal tools (features merged from the old Miqat app) ----
export type SavedSpeech = { id: string; title: string; html: string; minutes: number; date: string };
export type Dua = { id: string; text: string };
export type Tools = { library: SavedSpeech[]; duas: Dua[]; notes: string; points: string; checked: number[]; topic: string; minutes: number };
const TK = "miqat_tools_v1";
const defTools: Tools = { library: [], duas: [], notes: "", points: "", checked: [], topic: "", minutes: 15 };
export function getTools(): Tools {
  if (typeof window === "undefined") return defTools;
  try { const r = localStorage.getItem(TK); if (r) return { ...defTools, ...dec(r) }; } catch { /* ignore */ }
  return defTools;
}
export function saveTools(patch: Partial<Tools>) {
  localStorage.setItem(TK, enc({ ...getTools(), ...patch }));
}
export function exportAll(): string {
  return JSON.stringify({ hub: load(), tools: getTools() }, null, 2);
}
export function importAll(json: string) {
  const d = JSON.parse(json);
  if (d.hub) { localStorage.setItem(HUB, enc(d.hub)); window.dispatchEvent(new Event(EVT)); }
  if (d.tools) localStorage.setItem(TK, enc(d.tools));
}
