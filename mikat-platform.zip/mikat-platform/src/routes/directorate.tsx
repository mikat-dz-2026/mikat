import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Shell, Card } from "@/components/Shell";
import { getDirectives, addDirective, subscribe, fmtTime, type Directive } from "@/lib/store";

export const Route = createFileRoute("/directorate")({
  head: () => ({
    meta: [
      { title: "بوابة المديرية | ميقات الخطيب" },
      { name: "description", content: "لوحة تحكم المديرية: تعليمات وخطب موحدة وإحصائيات التزام المساجد." },
      { property: "og:title", content: "بوابة المديرية والشؤون الدينية" },
      { property: "og:description", content: "إرسال التعليمات ومتابعة التزام المساجد بتوقيت الخطب." },
    ],
  }),
  component: Directorate,
});

const mosques = [
  { name: "مسجد الأمير عبد القادر", min: 18 },
  { name: "مسجد كتشاوة", min: 21 },
  { name: "المسجد الأعظم", min: 19 },
  { name: "مسجد الفتح", min: 27 },
  { name: "مسجد النور", min: 16 },
  { name: "مسجد الرحمة", min: 24 },
];
const LIMIT = 20;

function Directorate() {
  const [list, setList] = useState<Directive[]>([]);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  useEffect(() => { const sync = () => setList(getDirectives()); sync(); return subscribe(sync); }, []);
  const [ok2, setOk2] = useState(false);
  const ok = mosques.filter((m) => m.min <= LIMIT).length;
  const pct = Math.round((ok / mosques.length) * 100);

  const send = () => {
    if (!title.trim() || !body.trim()) return;
    addDirective(title.trim(), body.trim()); setTitle(""); setBody(""); setOk2(true);
  };

  return (
    <Shell title="🏛️ بوابة المديرية">
      <div className="flex items-center justify-between rounded-2xl bg-gold p-3 text-sm font-bold text-accent-foreground">
        <span>⭐ اشتراك مدفوع مُفعّل</span><span>ولاية الجزائر</span>
      </div>
      <div className="grid grid-cols-3 gap-2 text-center">
        {[["مسجد", mosques.length], ["التزام", pct + "%"], ["تعليمة", list.length]].map(([l, v]) => (
          <div key={l} className="rounded-2xl border bg-card p-3"><div className="text-2xl font-bold text-primary">{v}</div><div className="text-xs text-muted-foreground">{l}</div></div>
        ))}
      </div>
      <Card title={`📊 مدة الخطب (الحد: ${LIMIT} دقيقة)`}>
        <div className="space-y-2">
          {mosques.map((m) => (
            <div key={m.name}>
              <div className="flex justify-between text-xs"><span>{m.name}</span><span>{m.min} د</span></div>
              <div className="h-3 overflow-hidden rounded-full bg-muted">
                <div className={`h-full rounded-full ${m.min <= LIMIT ? "bg-primary" : "bg-strong"}`} style={{ width: `${(m.min / 30) * 100}%` }} />
              </div>
            </div>
          ))}
        </div>
      </Card>
      <Card title="📤 إرسال تعليمة / خطبة موحدة">
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="عنوان التعليمة" className="mb-2 w-full rounded-xl border bg-background p-3" />
        <textarea value={body} onChange={(e) => setBody(e.target.value)} rows={4} placeholder="نص الخطبة أو التعليمة..." className="w-full rounded-xl border bg-background p-3" />
        <button onClick={send} className="mt-2 w-full rounded-xl bg-primary py-3 font-bold text-primary-foreground">📨 إرسال التعليمة الرسمية</button>
        {ok2 && <p className="mt-2 text-center text-sm font-bold text-primary">✅ نُشرت التعليمة وظهرت في حساب الإمام</p>}
      </Card>
      <Card title="🗂️ التعليمات المرسلة">
        <div className="space-y-2">
          {list.map((d) => (
            <div key={d.id} className="rounded-xl border p-3"><b>{d.title}</b><p className="text-sm text-muted-foreground">{d.body}</p><div className="text-xs text-muted-foreground">🕒 {fmtTime(d.date)}</div></div>
          ))}
        </div>
      </Card>
    </Shell>
  );
}
