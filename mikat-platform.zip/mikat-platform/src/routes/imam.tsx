import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Shell, Card } from "@/components/Shell";
import { ImamTools } from "@/components/ImamTools";
import { getQuestions, saveQuestions, summarize, type Question, getDirectives, type Directive, getSpeech, saveSpeech, subscribe, fmtTime, getTools, saveTools } from "@/lib/store";

export const Route = createFileRoute("/imam")({
  head: () => ({
    meta: [
      { title: "بوابة الإمام | ميقات الخطيب" },
      { name: "description", content: "محرر خطبة احترافي وملقّن آلي وصندوق أسئلة المصلين." },
      { property: "og:title", content: "بوابة الإمام | ميقات الخطيب" },
      { property: "og:description", content: "أدوات الإمام لإعداد وإلقاء خطبة الجمعة." },
    ],
  }),
  component: Imam,
});

const sample = "الحمد لله رب العالمين، والصلاة والسلام على أشرف المرسلين. أيها المؤمنون، إن صلة الرحم من أعظم القربات إلى الله تعالى، وقد قرنها الله بتقواه في كتابه العزيز. فمن وصل رحمه وصله الله، ومن قطعها قطعه الله. فلنبادر يا عباد الله إلى زيارة أقاربنا والسؤال عنهم، ولنصفح عمن أساء إلينا ابتغاء وجه الله.";

function Imam() {
  const [topic, setTopic] = useState("");
  const [minutes, setMinutes] = useState(15);
  const [words, setWords] = useState(0);
  const [font, setFont] = useState(32);
  const editor = useRef<HTMLDivElement>(null);
  const prompter = useRef<HTMLDivElement>(null);
  const [html, setHtml] = useState("");
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState(2);
  const [secs, setSecs] = useState(0);
  const [showPrompter, setShowPrompter] = useState(false);
  const [summary, setSummary] = useState("");
  const [copied, setCopied] = useState(false);
  const [qs, setQs] = useState<Question[]>([]);
  const [dirs, setDirs] = useState<Directive[]>([]);

  useEffect(() => {
    if (editor.current) editor.current.innerHTML = getSpeech() ?? sample;
    const sync = () => { setQs(getQuestions()); setDirs(getDirectives()); };
    sync();
    const tl = getTools(); setTopic(tl.topic); setMinutes(tl.minutes); countWords();
    return subscribe(sync);
  }, []);
  const [savedAt, setSavedAt] = useState("");
  const countWords = () => setWords((editor.current?.innerText || "").split(/\s+/).filter(Boolean).length);
  const doSave = () => { if (editor.current) { saveSpeech(editor.current.innerHTML); setSavedAt(new Date().toISOString()); countWords(); } };
  const insertMark = (label: string, cls: string) => {
    const el = editor.current; if (!el) return;
    const sel = window.getSelection();
    const span = document.createElement("span");
    span.className = cls; span.textContent = ` ${label} `;
    if (sel && sel.rangeCount && el.contains(sel.getRangeAt(0).commonAncestorContainer)) {
      const r = sel.getRangeAt(0); r.collapse(false); r.insertNode(span);
    } else el.appendChild(span);
    doSave();
  };
  const useContent = (title: string, body: string) => {
    if (!editor.current) return;
    if (title) { editor.current.innerHTML = body; setTopic(title); saveTools({ topic: title }); }
    else editor.current.innerHTML += body;
    doSave(); window.scrollTo({ top: 0, behavior: "smooth" });
  };

  useEffect(() => {
    if (!playing) return;
    let acc = 0;
    const t = setInterval(() => { acc += speed; const n = Math.floor(acc); if (n) { prompter.current?.scrollBy(0, n); acc -= n; } }, 50);
    let lock: { release: () => Promise<void> } | null = null;
    (navigator as unknown as { wakeLock?: { request: (t: string) => Promise<typeof lock> } }).wakeLock?.request("screen").then((l) => (lock = l)).catch(() => {});
    const c = setInterval(() => setSecs((s) => s + 1), 1000);
    return () => { clearInterval(t); clearInterval(c); lock?.release(); };
  }, [playing, speed]);

  const tone = (cls: string) => {
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0 || sel.isCollapsed) return alert("حدد كلمات من النص أولاً");
    const range = sel.getRangeAt(0);
    if (!editor.current?.contains(range.commonAncestorContainer)) return;
    const span = document.createElement("span");
    span.className = cls;
    span.appendChild(range.extractContents());
    range.insertNode(span);
    sel.removeAllRanges();
    doSave();
  };

  const openPrompter = () => { setHtml(editor.current?.innerHTML || ""); setSecs(0); setShowPrompter(true); };
  const text = () => editor.current?.innerText || "";
  const toggleAnswered = (id: string) => {
    const n = qs.map((q) => (q.id === id ? { ...q, answered: !q.answered } : q));
    setQs(n); saveQuestions(n);
  };
  const remain = minutes * 60 - secs;
  const fitSpeed = () => {
    const el = prompter.current; if (!el) return;
    const left = el.scrollHeight - el.clientHeight - el.scrollTop;
    setSpeed(Math.max(0.2, left / (Math.max(remain, 30) * 20)));
  };
  const el = prompter.current;
  const prog = el && el.scrollHeight > el.clientHeight ? el.scrollTop / (el.scrollHeight - el.clientHeight) : 0;
  const pace = secs < 5 ? "" : prog - secs / (minutes * 60) > 0.03 ? "متقدم ⏩" : secs / (minutes * 60) - prog > 0.03 ? "متأخر ⏪" : "في الوقت ✓";
  const mm = `${String(Math.floor(secs / 60)).padStart(2, "0")}:${String(secs % 60).padStart(2, "0")}`;

  if (showPrompter)
    return (
      <div className="prompter fixed inset-0 z-50 flex flex-col bg-prompter text-prompter-foreground">
        <div className="flex items-center justify-between gap-2 p-3">
          <button onClick={() => { setPlaying(false); setShowPrompter(false); }} className="rounded-lg bg-prompter-foreground/15 px-3 py-2 text-sm">إغلاق</button>
          <div className="text-center"><span className={`font-mono text-2xl ${remain <= 120 ? "text-strong" : "text-gold"}`}>{mm}</span><div className="text-xs">{pace} · المتبقي {Math.max(0, Math.ceil(remain / 60))} د</div></div>
          <button onClick={() => setPlaying(!playing)} className="rounded-lg bg-gold px-4 py-2 font-bold text-accent-foreground">{playing ? "إيقاف ⏸" : "تشغيل ▶"}</button>
        </div>
        <div className="grid grid-cols-[auto_1fr] items-center gap-x-2 gap-y-1 px-4 text-sm">
          <span>السرعة</span><input type="range" min={0.2} max={8} step={0.1} value={speed} onChange={(e) => setSpeed(+e.target.value)} className="accent-current" />
          <span>الخط</span><input type="range" min={20} max={56} value={font} onChange={(e) => setFont(+e.target.value)} className="accent-current" />
        </div>
        <button onClick={fitSpeed} className="mx-4 mt-2 rounded-lg bg-prompter-foreground/15 py-2 text-sm">⏱️ اضبط السرعة على وقت الخطبة ({minutes} د)</button>
        <div ref={prompter} onClick={() => setPlaying(false)} style={{ fontSize: font }} className="flex-1 overflow-y-auto px-6 py-[40vh] leading-[2.2]" dangerouslySetInnerHTML={{ __html: html }} />
      </div>
    );

  return (
    <Shell title="🎙️ بوابة الإمام">
      <Card title={`📢 تعليمات المديرية المستلمة (${dirs.length})`}>
        <div className="max-h-64 space-y-2 overflow-y-auto">
          {dirs.map((d) => (
            <div key={d.id} className="rounded-xl border border-gold bg-secondary p-3 text-sm">
              <b>{d.title}</b><p>{d.body}</p>
              <div className="mt-1 text-xs text-muted-foreground">🕒 {fmtTime(d.date)}</div>
            </div>
          ))}
        </div>
      </Card>
      <Card title="✍️ محرر خطبة احترافي">
        <input value={topic} onChange={(e) => { setTopic(e.target.value); saveTools({ topic: e.target.value }); }} placeholder="موضوع الجمعة" className="mb-2 w-full rounded-xl border bg-background p-3 font-bold" />
        <div className="mb-2 flex gap-2">
          {([["＋ وقفة", "⏸ وقفة", "tone-soft"], ["＋ دعاء", "🤲 دعاء", "tone-soft"], ["＋ آية", "﴿ آية ﴾", "tone-strong"]] as const).map(([b, l, c]) => (
            <button key={b} onMouseDown={(e) => e.preventDefault()} onClick={() => insertMark(l, c)} className="flex-1 rounded-xl bg-muted py-2 text-sm font-bold">{b}</button>
          ))}
        </div>
        <div className="mb-3 flex gap-2">
          <button onMouseDown={(e) => e.preventDefault()} onClick={() => tone("tone-strong")} className="flex-1 rounded-xl border-2 border-strong py-2 text-sm font-bold text-strong">نبرة قوية 🔴</button>
          <button onMouseDown={(e) => e.preventDefault()} onClick={() => tone("tone-soft")} className="flex-1 rounded-xl border-2 border-soft py-2 text-sm font-bold text-soft">نبرة عاطفية 🔵</button>
        </div>
        <div ref={editor} contentEditable suppressContentEditableWarning onBlur={doSave} onInput={countWords} className="min-h-56 rounded-xl border bg-background p-3 text-lg leading-loose outline-none focus:ring-2 focus:ring-ring" />
        <div className="mt-2 flex items-center justify-between text-sm text-muted-foreground">
          <span>{words} كلمة · ≈ {Math.max(1, Math.round(words / 110))} د إلقاء</span>
          <label className="flex items-center gap-1">المدة المستهدفة
            <input type="number" min={1} max={60} value={minutes} onChange={(e) => { const v = Math.max(1, +e.target.value || 1); setMinutes(v); saveTools({ minutes: v }); }} className="w-14 rounded-lg border bg-background p-1 text-center" /> د
          </label>
        </div>
        <button onClick={() => { if (editor.current && confirm("تفريغ المحرر لخطبة جديدة؟")) { editor.current.innerHTML = ""; setTopic(""); saveTools({ topic: "" }); doSave(); } }} className="mt-2 w-full text-sm text-muted-foreground">＋ خطبة جديدة (تفريغ المحرر)</button>
        <button onClick={doSave} className="mt-3 w-full rounded-xl border-2 border-primary py-2 font-bold text-primary">💾 حفظ الخطبة{savedAt && ` · ✅ ${fmtTime(savedAt)}`}</button>
        <button onClick={() => { doSave(); openPrompter(); }} className="mt-3 w-full rounded-xl bg-primary py-3 font-bold text-primary-foreground">⏱️ تشغيل الملقّن الآلي والمؤقت</button>
      </Card>

      <ImamTools onUse={useContent} onSaveCurrent={() => { doSave(); return { title: topic || "خطبة بدون عنوان", html: editor.current?.innerHTML || "", minutes }; }} />

      <Card title="🪄 تلخيص ونشر لفيسبوك">
        <button onClick={() => { setSummary(summarize(text())); setCopied(false); }} className="w-full rounded-xl bg-gold py-3 font-bold text-accent-foreground">🪄 تلخيص ونشر لفيسبوك بالذكاء الاصطناعي</button>
        {summary && (
          <>
            <textarea value={summary} onChange={(e) => setSummary(e.target.value)} rows={7} className="mt-3 w-full rounded-xl border bg-background p-3 text-sm" />
            <button onClick={() => { navigator.clipboard.writeText(summary); setCopied(true); }} className="w-full rounded-xl bg-primary py-2 font-bold text-primary-foreground">{copied ? "✅ تم النسخ" : "📋 نسخ بنقرة واحدة"}</button>
          </>
        )}
      </Card>

      <Card title={`📥 صندوق أسئلة المصلين (${qs.filter((q) => !q.answered).length} جديد)`}>
        <div className="space-y-2">
          {qs.length === 0 && <p className="text-sm text-muted-foreground">لا توجد أسئلة بعد.</p>}
          {[...qs].reverse().map((q) => (
            <div key={q.id} className={`rounded-xl border p-3 ${q.answered ? "opacity-50" : ""}`}>
              <div className="text-xs text-muted-foreground">{q.topic} · مجهول الهوية · 🕒 {fmtTime(q.date)}</div>
              <p className="my-1">{q.text}</p>
              <button onClick={() => toggleAnswered(q.id)} className="text-sm font-bold text-primary">{q.answered ? "↩️ إعادة فتح" : "✔️ تمت الإجابة في الدرس"}</button>
            </div>
          ))}
        </div>
      </Card>
    </Shell>
  );
}
