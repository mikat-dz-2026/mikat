import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "منصة ميقات الخطيب السحابية" },
      { name: "description", content: "منصة جزائرية لإعداد خطب الجمعة وتسيير المساجد: بوابة الإمام والمديرية والمصلين." },
      { property: "og:title", content: "منصة ميقات الخطيب السحابية" },
      { property: "og:description", content: "إعداد خطب الجمعة وتسيير المساجد في منصة واحدة." },
    ],
  }),
  component: Index,
});

const portals = [
  { to: "/imam" as const, icon: "🎙️", title: "بوابة الإمام", desc: "محرر خطبة، ملقّن آلي، نبرات صوتية، ملخص فيسبوك وصندوق الأسئلة." },
  { to: "/directorate" as const, icon: "🏛️", title: "بوابة المديرية والشؤون الدينية", desc: "إرسال التعليمات والخطب الموحدة ومتابعة التزام المساجد.", paid: true },
  { to: "/worshippers" as const, icon: "🤲", title: "بوابة المصلين", desc: "أرسل سؤالك الفقهي للإمام بسرية تامة." },
];

function Index() {
  return (
    <div className="mx-auto min-h-screen max-w-xl">
      <div className="bg-hero rounded-b-[2.5rem] px-6 pb-12 pt-14 text-center text-primary-foreground">
        <div className="text-5xl">🕌</div>
        <h1 className="mt-3 text-3xl leading-snug">منصة ميقات الخطيب<br /><span className="text-gold">السحابية</span></h1>
        <p className="mt-3 text-sm opacity-80">إعداد خطب الجمعة وتسيير المساجد في الجزائر</p>
      </div>
      <div className="-mt-6 space-y-4 px-4 pb-10">
        {portals.map((p) => (
          <div key={p.to} className="rounded-2xl border bg-card p-5 shadow-md">
            <div className="flex items-start gap-3">
              <span className="text-3xl">{p.icon}</span>
              <div className="flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-lg text-primary">{p.title}</h2>
                  {p.paid && <span className="rounded-full bg-gold px-2 py-0.5 text-xs font-bold text-accent-foreground">مدفوع</span>}
                </div>
                <p className="mt-1 text-sm text-muted-foreground">{p.desc}</p>
              </div>
            </div>
            <Link to={p.to} className="mt-4 block rounded-xl bg-primary py-3 text-center font-bold text-primary-foreground active:scale-[0.98]">دخول البوابة</Link>
          </div>
        ))}
      </div>
    </div>
  );
}
