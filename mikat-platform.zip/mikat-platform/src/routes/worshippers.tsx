import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Shell, Card } from "@/components/Shell";
import { addQuestion } from "@/lib/store";

export const Route = createFileRoute("/worshippers")({
  head: () => ({
    meta: [
      { title: "بوابة المصلين | ميقات الخطيب" },
      { name: "description", content: "أرسل سؤالك الفقهي حول خطبة اليوم للإمام بسرية تامة." },
      { property: "og:title", content: "بوابة المصلين | ميقات الخطيب" },
      { property: "og:description", content: "اسأل إمامك بسرية تامة." },
    ],
  }),
  component: Worshippers,
});

function Worshippers() {
  const [text, setText] = useState("");
  const [topic, setTopic] = useState("خطبة اليوم");
  const [sent, setSent] = useState(false);
  const send = () => {
    if (text.trim().length < 5) return;
    addQuestion(text.trim(), topic);
    setText(""); setSent(true);
  };
  return (
    <Shell title="🤲 بوابة المصلين">
      <Card title="اسأل الإمام">
        <p className="mb-3 text-sm text-muted-foreground">🔒 سؤالك يصل للإمام دون اسمك أو أي معلومة عنك.</p>
        <select value={topic} onChange={(e) => setTopic(e.target.value)} className="mb-2 w-full rounded-xl border bg-background p-3">
          {["خطبة اليوم", "أحكام الصلاة", "المعاملات", "الأسرة", "أخرى"].map((t) => <option key={t}>{t}</option>)}
        </select>
        <textarea value={text} onChange={(e) => { setText(e.target.value); setSent(false); }} rows={6} placeholder="اكتب سؤالك الفقهي هنا..." className="w-full rounded-xl border bg-background p-3 text-lg" />
        <button onClick={send} className="mt-2 w-full rounded-xl bg-primary py-3 font-bold text-primary-foreground">إرسال للإمام بسرية</button>
        {sent && <p className="mt-3 rounded-xl bg-secondary p-3 text-center font-bold text-primary">✅ وصل سؤالك للإمام، جزاك الله خيراً</p>}
      </Card>
    </Shell>
  );
}
