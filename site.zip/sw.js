const V='mikat-v1';
const SHELL=['./','index.html','manifest.json','icon-192.png','icon-512.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(V).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==V).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
 const r=e.request;if(r.method!=='GET')return;
 const u=new URL(r.url);
 if(u.origin===location.origin&&u.pathname.endsWith('.json')&&!u.pathname.endsWith('manifest.json')){
  e.respondWith(fetch(r).then(x=>{const c=x.clone();caches.open(V).then(ch=>ch.put(r,c));return x}).catch(()=>caches.match(r)));return}
 e.respondWith(caches.match(r).then(h=>{
  const n=fetch(r).then(x=>{if(x&&x.status===200&&(u.origin===location.origin||u.host==='fonts.gstatic.com'||u.host==='fonts.googleapis.com')){const c=x.clone();caches.open(V).then(ch=>ch.put(r,c))}return x}).catch(()=>h);
  return h||n}))});
