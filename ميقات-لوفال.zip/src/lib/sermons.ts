import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const CATEGORIES = ["عامة", "عقيدة", "عبادات", "أخلاق", "مناسبات", "سيرة", "أسرة ومجتمع"];

export const sermonsQuery = queryOptions({
  queryKey: ["sermons"],
  queryFn: async () => {
    const { data, error } = await supabase
      .from("sermons")
      .select("id,title,category,delivered_on,updated_at")
      .order("updated_at", { ascending: false });
    if (error) throw error;
    return data;
  },
});

export const sermonQuery = (id: string) =>
  queryOptions({
    queryKey: ["sermon", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("sermons").select("*").eq("id", id).single();
      if (error) throw error;
      return data;
    },
  });

export function hijri(d: Date | string) {
  return new Intl.DateTimeFormat("ar-SA-u-ca-islamic-umalqura", { day: "numeric", month: "long", year: "numeric" }).format(new Date(d));
}

