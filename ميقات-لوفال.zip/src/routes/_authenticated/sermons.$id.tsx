import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { ArrowRight, BookOpen, Minus, Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CATEGORIES, sermonQuery } from "@/lib/sermons";

export const Route = createFileRoute("/_authenticated/sermons/$id")({
  head: () => ({
    meta: [
      { title: "تحرير الخطبة — ميقات الخطيب" },
      { name: "description", content: "اكتب خطبتك وألقها بخط كبير." },
      { property: "og:title", content: "تحرير الخطبة — ميقات الخطيب" },
      { property: "og:description", content: "اكتب خطبتك وألقها بخط كبير." },
    ],
  }),
  loader: ({ context, params }) => context.queryClient.ensureQueryData(sermonQuery(params.id)),
  component: Editor,
});

function Editor() {
  const { id } = Route.useParams();
  const { data } = useSuspenseQuery(sermonQuery(id));
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [title, setTitle] = useState(data.title);
  const [category, setCategory] = useState(data.category);
  const [content, setContent] = useState(data.content);
  const [reading, setReading] = useState(false);
  const [size, setSize] = useState(28);
  const [status, setStatus] = useState("محفوظة");
  const first = useRef(true);

  useEffect(() => {
    if (first.current) { first.current = false; return; }
    setStatus("جارٍ الحفظ…");
    const t = setTimeout(async () => {
      const { error } = await supabase
        .from("sermons")
        .update({ title, category, content, updated_at: new Date().toISOString() })
        .eq("id", id);
      setStatus(error ? "تعذّر الحفظ" : "محفوظة");
      qc.invalidateQueries({ queryKey: ["sermons"] });
    }, 800);
    return () => clearTimeout(t);
  }, [title, category, content, id, qc]);

  async function remove() {
    if (!confirm("حذف هذه الخطبة نهائياً؟")) return;
    await supabase.from("sermons").delete().eq("id", id);
    await qc.invalidateQueries({ queryKey: ["sermons"] });
    toast.success("تم الحذف");
    navigate({ to: "/sermons" });
  }

  if (reading) {
    return (
      <main className="min-h-screen px-5 py-6">
        <div className="sticky top-0 flex items-center justify-between bg-background/90 py-2 backdrop-blur">
          <Button variant="ghost" onClick={() => setReading(false)}><Pencil /> تحرير</Button>
          <div className="flex gap-1">
            <Button variant="outline" size="icon" aria-label="تصغير الخط" onClick={() => setSize((s) => Math.max(18, s - 4))}><Minus /></Button>
            <Button variant="outline" size="icon" aria-label="تكبير الخط" onClick={() => setSize((s) => Math.min(64, s + 4))}><Plus /></Button>
          </div>
        </div>
        <article className="font-display mx-auto max-w-3xl leading-loose">
          <h1 className="mb-6 text-center font-bold text-primary" style={{ fontSize: size * 1.3 }}>{title}</h1>
          <div style={{ fontSize: size }} className="whitespace-pre-wrap">{content}</div>
        </article>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-3xl px-4 py-6">
      <div className="flex items-center justify-between">
        <Button asChild variant="ghost"><Link to="/sermons"><ArrowRight /> خطبي</Link></Button>
        <span className="text-xs text-muted-foreground">{status}</span>
      </div>
      <Input
        aria-label="عنوان الخطبة"
        className="font-display mt-4 h-14 text-2xl font-bold md:text-2xl"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />
      <div className="mt-3 flex gap-2">
        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger className="w-40" aria-label="التصنيف"><SelectValue /></SelectTrigger>
          <SelectContent>
            {CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
        <Button variant="secondary" onClick={() => setReading(true)}><BookOpen /> وضع الإلقاء</Button>
        <Button variant="ghost" size="icon" aria-label="حذف" className="mr-auto text-destructive" onClick={remove}><Trash2 /></Button>
      </div>
      <Textarea
        aria-label="نص الخطبة"
        placeholder="الحمد لله رب العالمين…"
        className="font-display mt-4 min-h-[60vh] text-xl leading-loose"
        value={content}
        onChange={(e) => setContent(e.target.value)}
      />
    </main>
  );
}
