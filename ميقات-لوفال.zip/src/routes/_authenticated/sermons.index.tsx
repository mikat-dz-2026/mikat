import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { LogOut, Plus, Search } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { CATEGORIES, hijri, sermonsQuery } from "@/lib/sermons";

export const Route = createFileRoute("/_authenticated/sermons/")({
  head: () => ({
    meta: [
      { title: "خطبي — ميقات الخطيب" },
      { name: "description", content: "قائمة خطبك المحفوظة." },
      { property: "og:title", content: "خطبي — ميقات الخطيب" },
      { property: "og:description", content: "قائمة خطبك المحفوظة." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(sermonsQuery),
  component: SermonsList,
});

function SermonsList() {
  const { data } = useSuspenseQuery(sermonsQuery);
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<string | null>(null);

  const list = data.filter(
    (s) => (!cat || s.category === cat) && (!q || s.title.includes(q)),
  );

  async function create() {
    const { data: row, error } = await supabase.from("sermons").insert({ title: "خطبة جديدة" }).select("id").single();
    if (error) { toast.error("تعذّر إنشاء الخطبة"); return; }
    navigate({ to: "/sermons/$id", params: { id: row.id } });
  }

  return (
    <main className="mx-auto max-w-3xl px-4 py-8">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold text-primary">خطبي</h1>
          <p className="text-sm text-muted-foreground">{hijri(new Date())}</p>
        </div>
        <Button variant="ghost" size="icon" aria-label="خروج" onClick={() => supabase.auth.signOut()}>
          <LogOut />
        </Button>
      </header>

      <div className="mt-6 flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input placeholder="ابحث بالعنوان" className="pr-9" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <Button onClick={create}><Plus /> خطبة</Button>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        {[null, ...CATEGORIES].map((c) => (
          <button key={c ?? "all"} onClick={() => setCat(c)}>
            <Badge variant={cat === c ? "default" : "secondary"}>{c ?? "الكل"}</Badge>
          </button>
        ))}
      </div>

      <ul className="mt-6 space-y-3">
        {list.map((s) => (
          <li key={s.id}>
            <Link to="/sermons/$id" params={{ id: s.id }} className="block rounded-xl border bg-card p-4 transition hover:border-primary">
              <div className="flex items-start justify-between gap-3">
                <h2 className="text-2xl font-bold">{s.title || "بلا عنوان"}</h2>
                <Badge variant="outline">{s.category}</Badge>
              </div>
              <p className="mt-1 text-xs text-muted-foreground">آخر تعديل: {hijri(s.updated_at)}</p>
            </Link>
          </li>
        ))}
        {list.length === 0 && (
          <p className="py-12 text-center text-muted-foreground">لا توجد خطب بعد. اضغط «خطبة» لكتابة أول خطبة.</p>
        )}
      </ul>
    </main>
  );
}
