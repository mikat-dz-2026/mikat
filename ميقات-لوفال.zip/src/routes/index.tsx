import { createFileRoute, Link } from "@tanstack/react-router";
import { BookOpen, Cloud, ShieldCheck, Type } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ميقات الخطيب — اكتب خطبك واحفظها بأمان" },
      { name: "description", content: "منصة مجانية للأئمة لكتابة الخطب وحفظها ومزامنتها بين الهاتف والحاسوب." },
      { property: "og:title", content: "ميقات الخطيب" },
      { property: "og:description", content: "اكتب خطبك واحفظها بأمان على كل أجهزتك." },
    ],
  }),
  component: Index,
});

const features = [
  { icon: Cloud, title: "محفوظة على الإنترنت", text: "خطبك معك على الهاتف والحاسوب، لا تضيع أبداً." },
  { icon: Type, title: "وضع الإلقاء", text: "خط كبير قابل للتكبير لقراءة مريحة على المنبر." },
  { icon: BookOpen, title: "تصنيف وبحث", text: "رتّب خطبك حسب الموضوع وابحث فيها بسهولة." },
  { icon: ShieldCheck, title: "خاصة بك وحدك", text: "لا يطّلع على خطبك أحد غيرك." },
];

function Index() {
  return (
    <main className="min-h-screen">
      <section className="mx-auto max-w-3xl px-5 pt-16 pb-12 text-center">
        <p className="text-accent font-display text-2xl">بسم الله الرحمن الرحيم</p>
        <h1 className="mt-4 text-5xl font-bold text-primary md:text-6xl">ميقات الخطيب</h1>
        <p className="mt-5 text-lg text-muted-foreground">
          رفيق الإمام في إعداد خطبه: اكتب، احفظ، وألقِ خطبتك من أي جهاز.
        </p>
        <div className="mt-8 flex justify-center gap-3">
          <Button asChild size="lg"><Link to="/sermons">ابدأ مجاناً</Link></Button>
          <Button asChild size="lg" variant="outline"><Link to="/auth">تسجيل الدخول</Link></Button>
        </div>
      </section>
      <section className="mx-auto grid max-w-4xl gap-4 px-5 pb-20 sm:grid-cols-2">
        {features.map((f) => (
          <div key={f.title} className="rounded-xl border bg-card p-6">
            <f.icon className="h-7 w-7 text-accent" />
            <h2 className="mt-3 text-2xl font-bold text-primary">{f.title}</h2>
            <p className="mt-1 text-muted-foreground">{f.text}</p>
          </div>
        ))}
      </section>
    </main>
  );
}

